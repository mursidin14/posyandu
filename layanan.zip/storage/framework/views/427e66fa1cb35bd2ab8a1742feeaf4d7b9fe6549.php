

<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/keuangan">Rekap Keuangan</a></li>
      <li class="breadcrumb-item active" aria-current="page">Kas Keluar</li>
    </ol>
</nav>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <form action="/keuangan" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('post'); ?>
                <input class=" form-control" name="jenis" type="text" style="display:none;" value="pemasukan">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label for="tanggal">Tanggal Kas Masuk</label>
                            <div class="input-group mb-3">
                                <input class="dateselect form-control" name="tanggal" type="text" placeholder="00/00/0000" autocomplete="off">
                                <div class="input-group-append">
                                    <span class="input-group-text" id="basic-addon2"><i class="fas fa-calendar"></i></span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label for="pemasukan">Kas Masuk</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['pemasukan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pemasukan"  id="pemasukan" value="<?php echo e(old('pemasukan')); ?>" placeholder="Rp." autocomplete="off">
                            <?php $__errorArgs = ['pemasukan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="deskripsi">Uraian</label>
                    <textarea type="text" class="form-control <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="deskripsi"  id="nama" value="<?php echo e(old('deskripsi')); ?>" autocomplete="off"></textarea>
                    <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button type="submit" class="btn btn-outline-dark">Simpan Data</button>
            </form>
        </div>
      </div>
    </div>
  </div>
<div class="card shadow p-3 mb-5 bg-white rounded border-left-primary">
  <div class="row mb-3" >
    <div class="col">
        <form action="<?php echo e(url('/filter/periodeKasKeluar')); ?>" method="get">
            <div class="row">
                <div class="col">
                    <div class="input-group">
                    <input class="form-control dateselect" type="text" name="dari" id="" autocomplete="off" value="<?php echo e($dari); ?>">
                        <div class="input-group-append">
                            <span class="input-group-text" id="basic-addon2"><i class="fas fa-calendar"></i></span>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="input-group">
                        <input class="form-control dateselect" type="text" name="sampai" id="" autocomplete="off"value="<?php echo e($sampai); ?>">
                        <div class="input-group-append">
                            <span class="input-group-text" id="basic-addon2"><i class="fas fa-calendar"></i></span>
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-outline-dark" ><i class="fas fa-search"></i></button>
            </div>
        </form>
    </div>
    <div class="col">
        <?php
            if($dari  == null){
                echo'<style>.dari{display:none;}</style>';
            }
        ?>
        <form action="<?php echo e(url('/filter/cetakpdfkeluar')); ?>" method="get" >
            <input type="text" name="dari" style="display: none" value="<?php echo e($dari); ?>">
            <input type="text" name="sampai" style="display: none" value="<?php echo e($sampai); ?>">
            <div class="dari">
                <button type="submit" style="display: block;" class="btn btn-outline-dark" ><i class="fas fa-">Cetak PDF</i></button>
            </div>
        </form>
    </div>
    <div class="col">
        <div class="d-flex justify-content-end">
            <button type="button" class="btn btn-outline-dark" data-toggle="modal" data-target="#exampleModal">
                Tambah
            </button>
        </div>
    </div>
</div>
<div class="">
    <?php if(session('status')): ?>
        <div class="alert alert-success">
                <?php echo e(session('status')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
        </div>
    <?php endif; ?>
</div>

    <div class="table-responsive">
    <table class="table table-hover" id="dataTable" width="100%" cellspacing="0">
        <thead style="background: #1cc88a">
          <tr>
            <th width="3%" scope="col">No</th>
            <th width="15%" scope="col">Tanggal</th>
            <th width="50%" scope="col">Uraian</th>
            <th width="15%" scope="col">Jumlah</th>
            <th width="10%" scope="col">Aksi</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $keluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <th scope="row"><?php echo e($key + $keluar->firstItem()); ?></th>
                <td><?php echo e(date('d F Y',strtotime($item->tanggal))); ?></td>
                <td><?php echo e($item->deskripsi); ?></td>
                <td>Rp.<?php echo e(number_format(($item->pengeluaran) , 0, ',', '.')); ?>,00</td>
                
                <td>
                    <form action="/keuangan/<?php echo e($item->id); ?>" method="post" class="d-inline" onsubmit="return confirm('Yakin Hapus Data?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="btn btn-danger" ><i class="fas fa-trash-alt"></i></button>
                    </form>
                    <a href="/keuangan/<?php echo e($item->id); ?>/edit" class="btn btn-success" ><i class="fas fa-edit"></i></a> 
                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr style="background: silver;">
                    <td></td>
                    <td colspan="2"><center><strong>JUMLAH KAS KELUAR</strong></center></td>
                    <td><strong>Rp.<?php echo e(number_format(($jumlah) , 0, ',', '.')); ?>,00</strong></td>
                    <td></td>
                </tr>
             
            </tr>
        </tbody>
        
    </table>
    <?php echo e($keluar->links()); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMENTARA\Feby TA\layanan\resources\views/keuangan/kaskeluar.blade.php ENDPATH**/ ?>