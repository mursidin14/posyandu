

<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
<div class="alert alert-success">
        <?php echo e(session('status')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
</div>
<?php endif; ?>
<div class="card shadow p-3 mb-5 bg-white rounded border-left-primary">
  <div class="card-header">
    Jadwal Layanan Posyandu
  </div>
  <div class="card-body">
    <div class="col-md-3">
    <form action="/blog" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <div class="form-group">
            <label for="tanggal_kegiatan">Tanggal Penimbangan</label>
            <div class="input-group mb-3">
                <input autocomplete="off" class="dateselect form-control" name="tanggal_kegiatan" type="text" placeholder="00/00/0000">
                <div class="input-group-append">
                    <span class="input-group-text" id="basic-addon2"><i class="fas fa-calendar"></i></span>
                </div>
                <?php $__errorArgs = ['tanggal_kegiatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="form-group">
            <label for="nama_kegiatan">Nama Layanan / Kegiatan</label>
            <input autocomplete="off" type="text" class="form-control <?php $__errorArgs = ['nama_kegiatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama_kegiatan"  id="nama_kegiatan	" value="<?php echo e(old('nama_kegiatan')); ?>">
            <?php $__errorArgs = ['nama_kegiatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="waktu">Jam Pelayanan</label>
            <input autocomplete="off" placeholder="00:00" type="text" class="form-control <?php $__errorArgs = ['waktu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="waktu"  id="waktu	" value="<?php echo e(old('waktu')); ?>">
            <?php $__errorArgs = ['waktu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button type="submit" class="btn btn-outline-dark">Simpan Data</button>
    </form>
    </div>
    <div class="m-4">
      <table class="table table-hover">
        <thead style="background: #1cc88a">
          <tr>
            <th scope="col">No</th>
            <th scope="col">Tanggal Kegiatan</th>
            <th scope="col">Nama Kegiatan</th>
            <th scope="col">Jam Kegiatan</th>
            <th scope="col">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php
              $i=1;
          ?>
          <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <tr>
          <th scope="row"><?php echo e($i++); ?></th>
          <td><?php echo e(date('d F Y',strtotime($item->tanggal_kegiatan))); ?></td>
            <td><?php echo e($item->nama_kegiatan); ?></td>
            <td><?php echo e($item->waktu); ?></td>
            <td>
              <form action="/blog/<?php echo e($item->id); ?>" method="post" class="d-inline" onsubmit="return confirm('Yakin Hapus Data?')">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button type="submit" class="btn btn-danger" ><i class="fas fa-trash-alt"></i></button>
              </form>
              
              <a href="/blog/<?php echo e($item->id); ?>/edit" class="btn btn-success" ><i class="fas fa-edit"></i></a> 
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>




  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMENTARA\Feby TA\layanan\resources\views/blog/index.blade.php ENDPATH**/ ?>