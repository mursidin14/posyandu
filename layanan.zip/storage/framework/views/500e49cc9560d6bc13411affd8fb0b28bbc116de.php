

<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/penimbangan">Data Timbangan</a></li>
      <li class="breadcrumb-item active" aria-current="page">Detail Timbangan Balita</li>
    </ol>
</nav>
<div class="card shadow p-3 mb-5 bg-white rounded border-left-primary">
    
   <div class="row">
    <div class="col">
        <?php $__currentLoopData = $penimbangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h3>
            Nama Balita : <?php echo e($item->balita->nama_balita); ?>

        </h3>
        <p>Berat Badan : <?php echo e($item->bb); ?> kilogram</p>
        <p>Tinggi Badan : <?php echo e($item->tb); ?> centimeter</p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="col">
        <div class="panel">
            <div id="chartNilai">ssss</div>
        </div>
    </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    
<script src="https://code.highcharts.com/highcharts.js"></script>
<script>

    //clickable Row
    jQuery(document).ready(function($) {
    $(".clickable-row").click(function() {
        window.location = $(this).data("href");
    });
    });

    Highcharts.chart('chartNilai', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Monthly Average Rainfall'
    },
    subtitle: {
        text: 'Source: WorldClimate.com'
    },
    xAxis: {
        categories: <?php echo json_encode($chart); ?>,
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Tanggal '
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:1f} </b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: 'Berat Badan',
        data: <?php echo json_encode($beratBadan); ?>


    }, {
        name: 'Tinggi Badan',
        data: <?php echo json_encode($tinggiBadan); ?>


    },]
});
              
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMENTARA\Feby TA\layanan\resources\views/timbangan/detail.blade.php ENDPATH**/ ?>