

<?php $__env->startSection('content'); ?>
<style>
    .border-left-primary {
      border-left: 0.25rem solid #4e73df !important;
    }
    .border-left-secondary {
      border-left: 0.25rem solid #858796 !important;
    }
    .border-left-success {
      border-left: 0.25rem solid #1cc88a !important;
    }
    .border-left-info {
      border-left: 0.25rem solid #36b9cc !important;
    }
    .border-left-warning {
      border-left: 0.25rem solid #f6c23e !important;
    }
    .border-left-danger {
      border-left: 0.25rem solid #e74a3b !important;
    }
    .border-left-light {
      border-left: 0.25rem solid #f8f9fc !important;
    }
    .border-left-dark {
      border-left: 0.25rem solid #5a5c69 !important;
    }
    </style>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/dashboard">Dashboard</a></li>
      <li class="breadcrumb-item active" aria-current="page">Data Balita</li>
    </ol>
</nav>
<div class="">
    <?php if(session('status')): ?>
        <div class="alert alert-success">
                <?php echo e(session('status')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
        </div>
    <?php endif; ?>
</div>

<div class="">
    <div class="card border-left-primary shadow p-3 mb-5 bg-white rounded">
        <div class="d-flex justify-content-lg-end mb-3">
            <a class="btn btn-outline-dark" href="/balita/create"><span class="icon text">
                <i class="fas fa-plus"></i>
            </span>Tambah Data</a>
    
        </div>
        <div class="table-responsive">
        <table class="table table-hover" id="dataTable" width="100%" cellspacing="0">
            <thead style="background: #1cc88a">
              <tr>
                <th scope="col">No</th>
                <th scope="col">Nama Balita</th>
                <th scope="col">Tempat Lahir</th>
                <th scope="col">Tanggal Lahir</th>
                <th scope="col">Nama Orangtua</th>
                <th scope="col">Pendidikan</th>
                <th scope="col">Pekerjaan</th>
                
                
                <th scope="col">Aksi</th>
            
              </tr>
            </thead>
            <tbody>
                
                <?php $i=1; ?>
              
                <?php $__currentLoopData = $balita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <th scope="row"><?php echo e($key + $balita->firstItem()); ?></th>
                    <td><?php echo e($item->nama_balita); ?></td>
                    <td><?php echo e($item->tpt_lahir); ?></td>
                    <td><?php echo e(date('d F Y',strtotime($item->tgl_lahir))); ?></td>
                    <td><?php echo e($item->nama_orangtua); ?></td>
                    <td><?php echo e($item->pendidikan); ?></td>
                    <td><?php echo e($item->pekerjaan); ?></td>
                    
                    
                    <td>
                        
                        <form action="/balita/<?php echo e($item->id); ?>" method="post" class="d-inline" onsubmit="return confirm('Yakin Hapus Data?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-danger" ><i class="fas fa-trash-alt"></i></button>
                        </form>
                        
                        <a href="/balita/<?php echo e($item->id); ?>/edit" class="btn btn-success" ><i class="fas fa-edit"></i></a> 
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            
        </table>
        <?php echo e($balita->links()); ?>

        </div>
    </div>
</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMENTARA\Feby TA\layanan\resources\views/balita/index.blade.php ENDPATH**/ ?>