

<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item active" aria-current="page">Rekap Keuangan</li>
      <li class="breadcrumb-item"><a href="/kasmasuk">Kas Masuk</a></li>
      <li class="breadcrumb-item"><a href="/kaskeluar">Kas Keluar</a></li>
    </ol>
</nav>
<form action="<?php echo e(url('keuangan/periode')); ?>" method="get">
   
    <input type="text" name="dari" id="">
    <input type="text" name="sampai" id="">
    <button type="submit">Submit</button>
</form>
<div class="">
    <div class="card shadow p-3 mb-5 bg-white rounded border-left-primary">
        <div class="table-responsive">
        <table class="table table-hover" id="dataTable" width="100%" cellspacing="0">
            <thead style="background: #1cc88a">
              <tr>
                <th width="3%" scope="col">No</th>
                <th width="15%" scope="col">Tanggal</th>
                <th width="35%" scope="col">Uraian</th>
                <th width="15%" scope="col">Pemasukan</th>
                <th width="15%" scope="col">Pengeluaran</th>
                <th width="15%" scope="col">Saldo</th>
              </tr>
            </thead>
            <tbody>
                <?php
                     $saldo = 0;
                ?>
                
                <?php $__currentLoopData = $keuangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                   
                    $saldo = $saldo + ($item->pemasukan - $item->pengeluaran);
                ?>
                <tr>
                <th scope="row"></th>
                    <td><?php echo e(date('d F Y',strtotime($item->tanggal))); ?></td>
                    <td><?php echo e($item->deskripsi); ?></td>
                    <?php
                    if ($item->pemasukan == 0) {
                        echo "<td></td>";
                    }
                    else {
                          echo "<td>Rp. <z class=\"pull-right\">".number_format(($item->pemasukan) , 0, ',', '.') . ",00"."</z></td>";
                    }
                    ?> 
                    <?php
                    if ($item->pengeluaran == 0) {
                        echo "<td></td>";
                    }
                    else {
                          echo "<td>Rp. <z class=\"pull-right\">".number_format(($item->pengeluaran) , 0, ',', '.') . ",00"."</z></td>";
                    }
                    ?> 
                    <td>Rp. <z class="pull-right"><?php echo number_format($saldo); ?>,00</z></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td></td>
                    <td colspan="2"><center><strong>JUMLAH</strong></center></td>

                    <td><b>Rp. <z class="pull-right"><?=number_format(($masuk) , 0, ',', '.') . ",00"?></z></b></td>
                  	 <td><b>Rp. <z class="pull-right"><?=number_format(($keluar) , 0, ',', '.') . ",00"?></z></b></td>
                  	 <td><b>Rp. <z class="pull-right"><?=number_format(($saldo) , 0, ',', '.') . ",00"?></z></b></td>
                  </tr>
            </tbody>
        </table>
        
        </div>
    </div>
</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMENTARA\Feby TA\layanan\resources\views/keuangan/filter.blade.php ENDPATH**/ ?>