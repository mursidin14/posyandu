

<?php $__env->startSection('content'); ?>
<div class="">
    <div class="card border-left-primary shadow p-3 mb-5 bg-white rounded">
        <div class="d-flex justify-content-lg-end mb-3">
            <a class="btn btn-outline-dark" href="/akun/create"><span class="icon text">
                <i class="fas fa-plus"></i>
            </span>Tambah Data</a>
    
        </div>
        <div class="table-responsive">
        <table class="table table-hover" id="dataTable" width="100%" cellspacing="0">
            <thead style="background: #1cc88a">
              <tr>
                <th scope="col">No</th>
                <th scope="col">Nama Akun</th>
                <th scope="col">Email</th>
                <th scope="col">Password</th>
                <th scope="col">Akun Dibuat</th>
                <th scope="col">Aksi</th>
            
              </tr>
            </thead>
            <tbody>
                
                <?php $i=1; ?>
              
                <?php $__currentLoopData = $akun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <th scope="row"><?php echo e($key + $akun->firstItem()); ?></th>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->email); ?></td>
                    <td><?php echo e($item->password); ?></td>
                    <td><?php echo e($item->created_at); ?></td>
                    <td>
                        
                        <form action="/akun/<?php echo e($item->id); ?>" method="post" class="d-inline" onsubmit="return confirm('Yakin Hapus Data?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-danger" ><i class="fas fa-trash-alt"></i></button>
                        </form>
                        
                        <a href="/akun/<?php echo e($item->id); ?>/edit" class="btn btn-success" ><i class="fas fa-edit"></i></a> 
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            
        </table>
        
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMENTARA\Feby TA\layanan\resources\views/akun/index.blade.php ENDPATH**/ ?>