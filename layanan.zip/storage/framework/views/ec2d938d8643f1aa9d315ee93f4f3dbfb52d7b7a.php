

<?php $__env->startSection('content'); ?>
<div class="card p-3 m-2">
    <form action="/keuangan" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
    <div class="row">
        <div class="col-3">
            <div class="form-group">
                <label for="pemasukan">Pemasukan</label>
                <input type="text" class="form-control <?php $__errorArgs = ['pemasukan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pemasukan"  id="pemasukan" value="<?php echo e(old('pemasukan')); ?>">
                <?php $__errorArgs = ['pemasukan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label for="pengeluaran">Pengeluaran</label>
                <input type="text" class="form-control <?php $__errorArgs = ['pengeluaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pengeluaran"  id="pengeluaran" value="<?php echo e(old('pengeluaran')); ?>">
                <?php $__errorArgs = ['pengeluaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
        <div class="form-group">
            <label for="deskripsi">Deskripsi</label>
            <textarea type="text" class="form-control <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="deskripsi"  id="nama" value="<?php echo e(old('deskripsi')); ?>"></textarea>
            <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button type="submit" class="btn btn-outline-dark">Simpan Data</button>
    </form>
</div>
<div class="">
    <?php if(session('status')): ?>
        <div class="alert alert-success">
                <?php echo e(session('status')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
        </div>
    <?php endif; ?>
</div>

<div class="">
    <div class="card p-3 m-2">
        <div class="table-responsive">
        <table class="table table-hover" id="dataTable" width="100%" cellspacing="0">
            <thead style="background: #1cc88a">
              <tr>
                <th scope="col">No</th>
                <th scope="col">Pemasukan</th>
                <th scope="col">Pengeluaran</th>
                <th scope="col">Deskripsi</th>
                <th scope="col">Saldo</th>
                <th scope="col">Aksi</th>
            
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $keuangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <th scope="row"><?php echo e($key + $keuangan->firstItem()); ?></th>
                    <td><?php echo e($item->pemasukan); ?></td>
                    <td><?php echo e($item->pengeluaran); ?></td>
                    <td><?php echo e($item->deskripsi); ?></td>
                    <td><?php echo e($sum); ?></td>
                    
                    
                    
                    <td>
                        
                        <form action="/keuangan/<?php echo e($item->id); ?>" method="post" class="d-inline" onsubmit="return confirm('Yakin Hapus Data?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-danger" ><i class="fas fa-trash-alt"></i></button>
                        </form>
                        <a href="/keuangan/<?php echo e($item->id); ?>" class="btn btn-primary" ><i class="fas fa-search"></i></a> 
                        <a href="/keuangan/<?php echo e($item->id); ?>/edit" class="btn btn-success" ><i class="fas fa-edit"></i></a> 
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            
        </table>
        <?php echo e($keuangan->links()); ?>

        </div>
    </div>
</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Feby TA\layanan\resources\views/keuangan/index.blade.php ENDPATH**/ ?>